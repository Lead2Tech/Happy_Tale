// app/javascript/application.js

import "@hotwired/turbo-rails"
import "./map";
